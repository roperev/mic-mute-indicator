/**
 *
 * @license MIT License
 *
 * Copyright (c) 2026 lewis he
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * @file      ImuDrv.hpp
 * @author    Lewis He (lewishe@outlook.com)
 * @date      2026-04-15
 */
#pragma once

#include "SensorBuildOpt.h"

#if !SENSORLIB_EXCLUDE_QMI8658
#include "sensor/imu/qmi8658/SensorQMI8658.hpp"
#endif

#if !SENSORLIB_EXCLUDE_BHI260_KLIO
#include "sensor/imu/bhi260/SensorBHI260AP_Klio.hpp"
#endif

#if !SENSORLIB_EXCLUDE_BHI260
#include "sensor/imu/bhi260/SensorBHI260AP.hpp"
#endif

#if !SENSORLIB_EXCLUDE_BHI360
#include "sensor/imu/bhi360/SensorBHI360.hpp"
#endif

#if !SENSORLIB_EXCLUDE_BHI_COMMON
#include "bosch/BoschSensorDataHelper.hpp"
#endif
