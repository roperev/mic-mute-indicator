/**
 *
 * @license MIT License
 *
 * Copyright (c) 2026 lewis he
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * @file      TouchDrvCST.hpp
 * @author    Lewis He (lewishe@outlook.com)
 * @date      2026-06-17
 * @brief     Aggregated header for Hynitron CST touch drivers
 */
#pragma once

#include "SensorBuildOpt.h"

#if !SENSORLIB_EXCLUDE_TOUCH_CST226
#include "touch/TouchDrvCST226.hpp"
#endif

#if !SENSORLIB_EXCLUDE_TOUCH_CST816
#include "touch/TouchDrvCST816.hpp"
#endif

#if !SENSORLIB_EXCLUDE_TOUCH_CST92XX
#include "touch/TouchDrvCST92xx.hpp"
#endif

#if !SENSORLIB_EXCLUDE_TOUCH_CST3530
#include "touch/TouchDrvCST3530.hpp"
#endif

#if !SENSORLIB_EXCLUDE_TOUCH_CSTXXX
#include "touch/TouchDrvCSTXXX.hpp"
#endif
